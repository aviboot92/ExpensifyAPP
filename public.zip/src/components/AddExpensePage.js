import React from 'react';

const AddExpensePage = () => (
    <div>
        <p>I am Add Expense page</p>
    </div>
);

export default AddExpensePage;