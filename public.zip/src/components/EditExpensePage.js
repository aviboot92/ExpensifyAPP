import React from 'react';

const EditExpensePage = (props) => {
    console.log(props);
    return(
        <div>
            <p>I am Edit Expense Page</p>
        </div>
    );
};

export default EditExpensePage;