import React from 'react';

const ExpenseDashBoardPage = () =>(
    <div>
        <p>I am Dash Board page</p>
    </div>
);

export default ExpenseDashBoardPage;