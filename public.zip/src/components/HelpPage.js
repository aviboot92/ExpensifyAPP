import React from 'react';

const HelpPage = () => (
    <div>
        <p>I am Help Page</p>
    </div>
);

export default HelpPage;